import { Component } from '@angular/core';

@Component({
  selector: 'app-programers',
  standalone: true,
  imports: [
    
  ],
  templateUrl: './programers.component.html',
  styleUrl: './programers.component.css'
})
export class ProgramersComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-pagina404',
  standalone: true,
  imports: [],
  templateUrl: './pagina404.component.html',
  styleUrl: './pagina404.component.css'
})
export class Pagina404Component {

}
